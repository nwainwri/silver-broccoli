//
//  TestManager.h
//  PizzaRestaurant
//
//  Created by Nathan Wainwright on 2018-08-05.
//  Copyright © 2018 Lighthouse Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KitchenDelegate.h"

@interface TestManager : NSObject <KitchenDelegate>



@end
